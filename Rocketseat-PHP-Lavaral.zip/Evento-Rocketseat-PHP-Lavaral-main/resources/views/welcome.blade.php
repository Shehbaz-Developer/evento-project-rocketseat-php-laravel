<x-layouts.app>
    <livewire:teste />
</x-layouts.app>