<x-layouts.app>
    <livewire:projects.index />
</x-layouts.app>