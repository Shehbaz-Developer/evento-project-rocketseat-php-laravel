<svg {{ $attributes }} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_3158_853)">
        <path d="M25 7L7 25" stroke="#C3C3D1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M25 25L7 7" stroke="#C3C3D1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <defs>
        <clipPath id="clip0_3158_853">
            <rect width="32" height="32" fill="white"/>
        </clipPath>
    </defs>
</svg>
