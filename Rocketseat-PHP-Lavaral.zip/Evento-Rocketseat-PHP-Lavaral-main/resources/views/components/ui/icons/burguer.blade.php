<svg {{ $attributes }} viewBox="0 0 32 33" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_3137_2193)">
        <path d="M5 16.049H27" stroke="#C3C3D1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M5 8.04895H27" stroke="#C3C3D1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M5 24.049H27" stroke="#C3C3D1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <defs>
        <clipPath id="clip0_3137_2193">
            <rect width="32" height="32" fill="white" transform="translate(0 0.0489502)"/>
        </clipPath>
    </defs>
</svg>
