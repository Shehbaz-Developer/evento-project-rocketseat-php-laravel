<svg {{ $attributes }} viewBox="0 0 21 21" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M10.5006 18.4167C10.5006 18.4167 17.1673 15.0833 17.1673 10.0833V4.25L10.5006 1.75L3.83398 4.25V10.0833C3.83398 15.0833 10.5006 18.4167 10.5006 18.4167Z" stroke="#C0F7B4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M13.25 8L9.43407 12L8 10.5744" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
