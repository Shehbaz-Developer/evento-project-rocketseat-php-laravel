<svg {{ $attributes }} viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_3137_2312)">
        <path d="M12 20.75V4.25" stroke="#1D8338" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M5.25 11L12 4.25L18.75 11" stroke="#1D8338" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </g>
    <defs>
        <clipPath id="clip0_3137_2312">
            <rect width="24" height="24" fill="white" transform="translate(0 0.5)"/>
        </clipPath>
    </defs>
</svg>
