<svg {{ $attributes }} viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g clip-path="url(#clip0_3137_2340)">
        <g clip-path="url(#clip1_3137_2340)">
            <path d="M3.75 12.5H20.25" stroke="#94A3B8" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
        </g>
    </g>
    <defs>
        <clipPath id="clip0_3137_2340">
            <rect width="24" height="24" fill="white" transform="translate(0 0.5)"/>
        </clipPath>
        <clipPath id="clip1_3137_2340">
            <rect width="24" height="24" fill="white" transform="translate(0 0.5)"/>
        </clipPath>
    </defs>
</svg>
