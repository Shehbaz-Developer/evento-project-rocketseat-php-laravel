<svg {{ $attributes }} viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 4.25L12 20.75" stroke="#881337" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M18.75 14L12 20.75L5.25 14" stroke="#881337" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
