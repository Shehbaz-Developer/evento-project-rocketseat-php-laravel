<svg {{ $attributes }} viewBox="0 0 18 19" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M9 17.0977C13.1421 17.0977 16.5 13.7399 16.5 9.59775C16.5 5.45561 13.1421 2.09775 9 2.09775C4.85786 2.09775 1.5 5.45561 1.5 9.59775C1.5 13.7399 4.85786 17.0977 9 17.0977Z" stroke="#C3C3D1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M9 5.0979V9.5979L12 11.0979" stroke="#C3C3D1" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
