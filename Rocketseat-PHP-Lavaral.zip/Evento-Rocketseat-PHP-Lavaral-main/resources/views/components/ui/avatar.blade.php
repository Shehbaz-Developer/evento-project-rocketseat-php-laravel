<div class="bg-[#7677FF] w-10 h-10 rounded-full object-cover overflow-hidden flex items-end">
    <img src="{{ $src }}"/>
</div>
