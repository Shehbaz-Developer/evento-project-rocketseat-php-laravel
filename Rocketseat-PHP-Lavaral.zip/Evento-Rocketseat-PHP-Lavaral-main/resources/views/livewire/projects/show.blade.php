<div class="col-span-2">
    <x-projects.card :$project />
</div>